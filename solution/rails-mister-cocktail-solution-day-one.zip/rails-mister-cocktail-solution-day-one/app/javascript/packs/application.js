import 'bootstrap';
import improveDropdown from '../components/select';

improveDropdown();
